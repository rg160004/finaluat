// Copyright (c) 2023, opex and contributors
// For license information, please see license.txt

 frappe.ui.form.on("sa", {
 	refresh(frm) {
    const intervention_type = frm.doc.intervention_type
  
    
    console.log('intervention_type: ', intervention_type)
 	},
 });
