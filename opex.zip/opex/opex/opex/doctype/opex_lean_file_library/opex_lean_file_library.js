// Copyright (c) 2023, opex and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Opex Lean File Library", {
// 	refresh(frm) {

// 	},
// });
