
import frappe
from frappe.model.document import Document


def popup_realtime_event(doc, method):
    print('---------------------events------raghav:', method)
    # frappe.connect()
   # doc.notify_update()
    frappe.publish_realtime(
        'show_popup', {'method': method}, user=frappe.session.user)
